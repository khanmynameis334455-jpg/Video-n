# একই স্বপ্ন, দুই পথ — Remotion প্রজেক্ট (72.3s, 1920x1080, 30fps)

npm install
npx remotion studio        # প্রিভিউ
npx remotion render Main out/video.mp4   # রেন্ডার (MP4)
