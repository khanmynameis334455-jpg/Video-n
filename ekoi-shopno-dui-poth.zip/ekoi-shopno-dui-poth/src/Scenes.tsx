import React from 'react';
import {interpolate} from 'remotion';
import {Scene, useG} from './Scene';
import {sf} from './data';
import {Character, LOOKS} from './Character';
import {Bus, FactoryBg, FarmBg, RoomBg, SewingTable, VillageBg} from './Backgrounds';
import {Clock, Pill, Pop, Stamp} from './ui';

const useIn = () => {
  const g = useG();
  return (a: number, b: number) => g >= sf(a) && g < sf(b);
};
const ramp = (g: number, a: number, b: number, v0: number, v1: number) =>
  interpolate(g, [sf(a), sf(b)], [v0, v1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

/* ১: হুক (মোশন গ্রাফিক্স) 0 - 9.46 */
const S1In: React.FC = () => {
  const g = useG();
  const p = ramp(g, 5.24, 5.9, 0, 1);
  return (
    <>
      <VillageBg time="morning" />
      {p > 0 && (
        <>
          <div style={{position: 'absolute', left: 0, top: 0, width: 960 * p, height: 1080, overflow: 'hidden'}}>
            <div style={{position: 'absolute', left: 0, top: 0, width: 960, height: 1080}}><FactoryBg /></div>
          </div>
          <div style={{position: 'absolute', right: 0, top: 0, width: 960 * p, height: 1080, overflow: 'hidden'}}>
            <div style={{position: 'absolute', right: 0, top: 0, width: 960, height: 1080}}><FarmBg /></div>
          </div>
          <div style={{position: 'absolute', left: 956, top: 0, width: 8, height: 1080, background: '#fff', opacity: p}} />
          <Character x={480} y={960} S={1.4} look={LOOKS.rafiqAdult} expr="sad" opacity={p} />
          <Character x={1440} y={960} S={1.4} look={LOOKS.kabirAdult} expr="happy" flip opacity={p} />
          <Pill at={5.6} until={9.46} text="গার্মেন্টস" x={480} y={150} color="#455A64" />
          <Pill at={5.9} until={9.46} text="খামার" x={1440} y={150} color="#43A047" />
        </>
      )}
      <Stamp at={0.14} until={3.8} text="একই গ্রাম" x={960} y={250} color="#43A047" />
      <Stamp at={1.32} until={3.8} text="একই স্কুল" x={960} y={450} color="#1E88E5" rot={3} />
      <Stamp at={2.52} until={3.8} text="একই স্বপ্ন" x={960} y={650} color="#FB8C00" />
      <Pop at={3.84} until={5.3} emoji="📅" x={960} y={300} size={200} />
      <Stamp at={3.84} until={5.3} text="১০ বছর পর" x={960} y={560} size={150} />
      <Stamp at={7.1} until={8.05} text="দুই রকম জীবন!" x={960} y={540} size={120} color="#8E24AA" />
      <Stamp at={8.1} until={9.46} text="কেন?" x={960} y={560} size={220} />
      <Pop at={8.1} until={9.46} emoji="❓" x={380} y={300} size={200} pulse />
      <Pop at={8.1} until={9.46} emoji="❓" x={1540} y={300} size={200} pulse />
    </>
  );
};

/* ২: শৈশব 9.46 - 22.62 */
const S2In: React.FC = () => {
  const is = useIn();
  return (
    <>
      <VillageBg time="day" />
      <Character x={700} y={960} S={1.55} look={LOOKS.kabirKid} expr="happy" talking={is(15.74, 19.86)} />
      <Character x={1180} y={960} S={1.55} flip look={LOOKS.rafiqKid} expr="happy" talking={is(19.86, 22.6)} />
      <Pill at={9.46} until={15.7} text="রফিক" x={1180} y={400} color="#1E88E5" />
      <Pill at={10.28} until={15.7} text="কবির" x={700} y={400} color="#43A047" />
      <Pop at={17.2} until={19.8} emoji="❤️" x={940} y={560} size={110} pulse />
    </>
  );
};

/* ৩ক: আলাদা পথ — বাস 22.62 - 28.6 */
const S3aIn: React.FC = () => {
  const g = useG();
  const busX = g < sf(26.2) ? ramp(g, 24.0, 25.0, -700, 620) : ramp(g, 26.2, 28.4, 620, 2700);
  const rx = ramp(g, 25.0, 25.9, 900, 640);
  const gone = g >= sf(26.0);
  return (
    <>
      <VillageBg time="day" />
      <Bus x={busX} />
      <Character x={rx} y={960} S={1.6} look={LOOKS.rafiqKid} expr="happy" opacity={gone ? 0 : 1} />
      <Character x={1250} y={960} S={1.6} flip look={LOOKS.kabirKid} expr={g > sf(27.4) ? 'sad' : 'happy'} pose={g > sf(24.8) ? 'wave' : 'idle'} />
      <Pop at={22.62} until={24.6} emoji="🎓" x={1070} y={380} size={150} />
      <Pop at={26.8} until={28.6} emoji="🏙️" x={1500} y={330} size={160} />
    </>
  );
};

/* ৩খ: কবিরের ছোট্ট খামার 28.6 - 33.88 */
const S3bIn: React.FC = () => (
  <>
    <FarmBg />
    <Character x={960} y={960} S={1.9} look={LOOKS.kabirAdult} expr="happy" pose="idle" />
    <Pop at={28.7} until={33.8} emoji="🐄" x={560} y={500} size={120} />
    <Pop at={30.2} until={33.8} emoji="🐓" x={1360} y={520} size={110} />
    <Pop at={32.0} until={33.8} emoji="💪" x={1180} y={420} size={110} pulse />
  </>
);

/* ৪: রফিকের সংগ্রাম 33.88 - 46.6 */
const S4In: React.FC = () => {
  const is = useIn();
  return (
    <>
      <FactoryBg />
      <SewingTable x={1250} y={760} />
      <Character x={760} y={960} S={1.9} look={LOOKS.rafiqAdult} expr={is(37.56, 42.1) ? 'worry' : 'sad'} tremble={is(37.56, 42.1)} />
      <Clock at={33.88} until={37.5} x={1500} y={300} h0={6} h1={10} />
      <Pop at={33.88} until={36.2} emoji="☀️" x={1180} y={180} size={110} />
      <Pop at={36.2} until={37.56} emoji="🌙" x={1180} y={180} size={110} />
      <Pop at={37.56} until={42.1} emoji="💤" x={940} y={380} size={110} />
      <Pop at={37.56} until={42.1} emoji="⏳" x={1500} y={300} size={160} pulse />
      <Pop at={42.1} until={46.6} emoji="🏠" x={1350} y={280} size={130} />
      <Pop at={42.74} until={46.6} emoji="🛒" x={1560} y={280} size={130} />
      <Pop at={43.5} until={46.6} emoji="💸" x={1450} y={470} size={130} />
      <Pop at={44.5} until={46.6} emoji="👛" x={1000} y={330} size={120} />
    </>
  );
};

/* ৫: মায়ের ফোন 46.6 - 51.22 */
const S5In: React.FC = () => {
  const is = useIn();
  return (
    <>
      <div style={{position: 'absolute', left: 0, top: 0, width: 960, height: 1080, overflow: 'hidden'}}>
        <div style={{position: 'absolute', left: 0, top: 0, width: 960, height: 1080}}><RoomBg /></div>
      </div>
      <div style={{position: 'absolute', right: 0, top: 0, width: 960, height: 1080, overflow: 'hidden'}}>
        <div style={{position: 'absolute', right: 0, top: 0, width: 960, height: 1080}}><VillageBg time="day" /></div>
      </div>
      <div style={{position: 'absolute', left: 956, top: 0, width: 8, height: 1080, background: '#fff'}} />
      <Character x={480} y={940} S={1.6} look={LOOKS.rafiqAdult} expr={is(49.68, 51.22) ? 'cry' : 'sad'} pose="phone" talking={is(49.68, 51.22)} tremble={is(49.68, 51.22)} />
      <Character x={1440} y={940} S={1.6} flip look={LOOKS.ma} expr="worry" pose="phone" talking={is(46.6, 49.6)} />
      <Pop at={46.6} until={51.22} emoji="📞" x={960} y={560} size={150} pulse />
    </>
  );
};

/* ৬: গ্রামবাসীর বিদ্রূপ 51.22 - 53.4 */
const S6In: React.FC = () => (
  <>
    <VillageBg time="day" />
    <Character x={330} y={960} S={1.5} look={LOOKS.elder1} expr="laugh" tremble />
    <Character x={700} y={960} S={1.5} look={LOOKS.elder2} expr="laugh" tremble talking />
    <Character x={1070} y={960} S={1.5} flip look={LOOKS.elder3} expr="laugh" tremble />
    <Character x={1560} y={960} S={1.6} flip look={LOOKS.kabirAdult} expr="sad" pose="head" />
    <Pop at={51.3} until={53.4} emoji="😂" x={200} y={400} size={100} />
    <Pop at={51.5} until={53.4} emoji="😂" x={1190} y={400} size={100} />
  </>
);

/* ৭: দেখা 53.4 - 66.27 */
const S7In: React.FC = () => {
  const g = useG();
  const is = useIn();
  const hug = g >= sf(64.9);
  const rx = hug ? ramp(g, 64.86, 65.6, 560, 880) : ramp(g, 53.4, 54.4, -150, 560);
  const kx = hug ? ramp(g, 64.86, 65.6, 1360, 1060) : 1360;
  const rexpr = is(53.4, 56) ? 'surprised' : is(56.7, 58) ? 'sad' : 'happy';
  return (
    <>
      <FarmBg big />
      <Character x={rx} y={960} S={1.9} look={LOOKS.rafiqEid} expr={rexpr} pose={hug ? 'hug' : 'idle'} talking={is(53.4, 58)} />
      <Character x={kx} y={960} S={1.9} flip look={LOOKS.kabirAdult} expr="happy" pose={hug ? 'hug' : 'idle'} talking={is(58, 59.94) || is(64.86, 66.27)} />
      <Stamp at={59.94} until={64.8} text="সঠিক সিদ্ধান্ত" x={380} y={230} size={72} color="#43A047" rot={-3} />
      <Stamp at={61.36} until={64.8} text="পরিশ্রম" x={960} y={230} size={72} color="#FB8C00" rot={2} />
      <Stamp at={63.0} until={64.8} text="ধৈর্য" x={1500} y={230} size={72} color="#1E88E5" rot={-2} />
      <Pop at={65.3} emoji="❤️" x={800} y={520} size={110} pulse />
      <Pop at={65.5} emoji="❤️" x={1120} y={480} size={110} pulse />
    </>
  );
};

/* ৮: শেষ বার্তা ও CTA 66.27 - 72.3 (অডিও নেই) */
const S8In: React.FC = () => {
  const g = useG();
  const dx = ramp(g, 66.27, 72.3, 0, 260);
  return (
    <>
      <VillageBg time="sunset" />
      <Character x={760 + dx} y={960} S={1.9} look={LOOKS.rafiqEid} expr="happy" />
      <Character x={1160 + dx} y={960} S={1.9} look={LOOKS.kabirAdult} expr="happy" />
      <Stamp at={66.5} until={69.4} text="সফলতা পেশার নামে আসে না" x={960} y={170} size={66} color="#E65100" rot={-2} />
      <Stamp at={67.6} until={69.4} text="আসে সঠিক সিদ্ধান্ত, পরিশ্রম আর ধৈর্যে" x={960} y={310} size={56} color="#2E7D32" rot={2} />
      <Stamp at={69.5} until={72.3} text="👍 লাইক" x={420} y={230} size={80} color="#1E88E5" rot={-3} />
      <Stamp at={70.2} until={72.3} text="↗ শেয়ার" x={960} y={230} size={80} color="#43A047" rot={2} />
      <Stamp at={70.9} until={72.3} text="🔔 সাবস্ক্রাইব" x={1500} y={230} size={80} color="#E53935" rot={-2} />
    </>
  );
};

export const AllScenes: React.FC = () => (
  <>
    <Scene a={0} b={9.46}><S1In /></Scene>
    <Scene a={9.46} b={22.62}><S2In /></Scene>
    <Scene a={22.62} b={28.6}><S3aIn /></Scene>
    <Scene a={28.6} b={33.88}><S3bIn /></Scene>
    <Scene a={33.88} b={46.6}><S4In /></Scene>
    <Scene a={46.6} b={51.22} shake={3}><S5In /></Scene>
    <Scene a={51.22} b={53.4} shake={7}><S6In /></Scene>
    <Scene a={53.4} b={66.27}><S7In /></Scene>
    <Scene a={66.27} b={72.3}><S8In /></Scene>
  </>
);
