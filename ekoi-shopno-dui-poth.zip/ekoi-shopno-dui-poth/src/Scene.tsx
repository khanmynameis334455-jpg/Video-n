import React, {createContext, useContext} from 'react';
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame} from 'remotion';
import {sf} from './data';

const Ctx = createContext(0);
/** পুরো ভিডিওর গ্লোবাল ফ্রেম (সিনের ভেতর থেকেও) */
export const useG = () => useCurrentFrame() + useContext(Ctx);

const Inner: React.FC<{shake: number; children: React.ReactNode}> = ({shake, children}) => {
  const f = useCurrentFrame();
  const op = interpolate(f, [0, 6], [0, 1], {extrapolateRight: 'clamp'});
  const dx = shake ? Math.sin(f * 2.1) * shake : 0;
  const dy = shake ? Math.cos(f * 2.7) * shake : 0;
  return (
    <AbsoluteFill style={{opacity: op, transform: `translate(${dx}px,${dy}px) scale(${shake ? 1.02 : 1})`}}>
      {children}
    </AbsoluteFill>
  );
};

export const Scene: React.FC<{a: number; b: number; shake?: number; children: React.ReactNode}> = ({a, b, shake = 0, children}) => {
  const from = sf(a);
  const dur = sf(b) - from;
  return (
    <Sequence from={from} durationInFrames={dur}>
      <Ctx.Provider value={from}>
        <Inner shake={shake}>{children}</Inner>
      </Ctx.Provider>
    </Sequence>
  );
};
