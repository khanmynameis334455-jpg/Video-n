import React from 'react';
import {useG} from './Scene';

const D = '#222';
const Svg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width="100%" height="100%" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice" style={{position: 'absolute', left: 0, top: 0}}>{children}</svg>
);

export const VillageBg: React.FC<{time?: 'morning' | 'day' | 'sunset'}> = ({time = 'day'}) => {
  const sky = time === 'morning' ? ['#FFD9A0', '#BFE3F5'] : time === 'sunset' ? ['#FF9966', '#FFE0A0'] : ['#8ED1F5', '#E8F7FF'];
  const sunY = time === 'day' ? 200 : 560;
  return (
    <Svg>
      <defs><linearGradient id={'sky' + time} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={sky[0]} /><stop offset="1" stopColor={sky[1]} /></linearGradient></defs>
      <rect width={1920} height={1080} fill={`url(#sky${time})`} />
      <circle cx={1500} cy={sunY} r={90} fill="#FFE08A" />
      <ellipse cx={500} cy={170} rx={150} ry={42} fill="#fff" opacity={0.85} />
      <ellipse cx={1000} cy={110} rx={110} ry={32} fill="#fff" opacity={0.85} />
      <rect y={700} width={1920} height={380} fill="#86C06C" />
      <polygon points="0,880 1920,850 1920,1080 0,1080" fill="#D8B481" />
      <rect x={170} y={420} width={70} height={400} fill="#7B5236" stroke={D} strokeWidth={4} />
      {[[205, 380, 150], [90, 450, 110], [330, 450, 110]].map(([cx, cy, r], i) => <circle key={i} cx={cx} cy={cy} r={r} fill="#3E8E41" stroke={D} strokeWidth={4} />)}
      <rect x={1250} y={560} width={380} height={250} fill="#E7CFA0" stroke={D} strokeWidth={4} />
      <polygon points="1215,565 1440,430 1665,565" fill="#9AA5B1" stroke={D} strokeWidth={4} />
      <rect x={1400} y={650} width={90} height={160} fill="#6b4a2f" stroke={D} strokeWidth={4} />
      {time === 'sunset' && <rect width={1920} height={1080} fill="#FF7A30" opacity={0.15} />}
    </Svg>
  );
};

export const FactoryBg: React.FC = () => (
  <Svg>
    <rect width={1920} height={1080} fill="#D9D4C7" />
    <rect y={800} width={1920} height={280} fill="#A7A090" />
    {[200, 720, 1240].map((x) => <g key={x}><rect x={x} y={200} width={380} height={300} fill="#BFE3F5" stroke={D} strokeWidth={5} /><line x1={x + 190} y1={200} x2={x + 190} y2={500} stroke={D} strokeWidth={5} /></g>)}
    {[300, 900, 1500].map((x) => <rect key={x} x={x} y={60} width={220} height={20} fill="#FFF6B0" stroke={D} strokeWidth={3} />)}
    {[0, 1, 2, 3].map((i) => <circle key={i} cx={1650 + (i % 2) * 70} cy={640 - Math.floor(i / 2) * 70} r={34} fill={['#E57373', '#64B5F6', '#FFD54F', '#81C784'][i]} stroke={D} strokeWidth={3} />)}
  </Svg>
);

export const SewingTable: React.FC<{x: number; y: number}> = ({x, y}) => {
  const g = useG();
  const n = Math.abs(Math.sin(g / 2)) * 22;
  return (
    <svg width={1} height={1} style={{position: 'absolute', left: x, top: y, overflow: 'visible'}}>
      <rect x={-200} y={0} width={400} height={30} fill="#8D6E63" stroke={D} strokeWidth={4} />
      <rect x={-180} y={30} width={26} height={170} fill="#6D4C41" stroke={D} strokeWidth={4} />
      <rect x={154} y={30} width={26} height={170} fill="#6D4C41" stroke={D} strokeWidth={4} />
      <path d="M-120,0 L-120,-90 Q-120,-130 -70,-130 L110,-130 L110,-80 L60,-80 L60,0Z" fill="#455A64" stroke={D} strokeWidth={4} />
      <line x1={90} y1={-80} x2={90} y2={-60 + n} stroke="#ddd" strokeWidth={5} />
      <rect x={-60} y={-20} width={120} height={20} fill="#E57373" stroke={D} strokeWidth={3} />
    </svg>
  );
};

export const RoomBg: React.FC = () => (
  <Svg>
    <rect width={1920} height={1080} fill="#34416B" />
    <rect y={820} width={1920} height={260} fill="#4B3B34" />
    <rect x={200} y={180} width={360} height={340} fill="#1B2547" stroke={D} strokeWidth={5} />
    <circle cx={440} cy={290} r={50} fill="#FFF3B0" />
    <rect x={1100} y={600} width={600} height={230} rx={20} fill="#8E6B4F" stroke={D} strokeWidth={5} />
    <rect x={1100} y={560} width={600} height={80} rx={20} fill="#C9B79C" stroke={D} strokeWidth={5} />
    <circle cx={960} cy={120} r={70} fill="#FFE08A" opacity={0.35} />
    <circle cx={960} cy={120} r={22} fill="#FFE08A" stroke={D} strokeWidth={3} />
  </Svg>
);

const Cow: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x},${y}) scale(${s})`} stroke={D} strokeWidth={4}>
    {[-60, -30, 40, 70].map((lx) => <rect key={lx} x={lx} y={30} width={18} height={70} fill="#fff" />)}
    <rect x={-100} y={-40} width={220} height={90} rx={40} fill="#fff" />
    <ellipse cx={-30} cy={-5} rx={26} ry={18} fill="#6D4C41" />
    <ellipse cx={50} cy={10} rx={22} ry={16} fill="#6D4C41" />
    <rect x={-160} y={-50} width={80} height={65} rx={26} fill="#fff" />
    <rect x={-165} y={-5} width={55} height={25} rx={12} fill="#F4B6B6" />
    <circle cx={-125} cy={-30} r={5} fill={D} />
  </g>
);
const Hen: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`} stroke={D} strokeWidth={3}>
    <ellipse cx={0} cy={0} rx={34} ry={26} fill="#D9822B" />
    <circle cx={-30} cy={-24} r={14} fill="#D9822B" />
    <polygon points="-44,-24 -56,-20 -44,-16" fill="#FFC107" />
    <circle cx={-30} cy={-40} r={6} fill="#E53935" />
  </g>
);

export const FarmBg: React.FC<{big?: boolean}> = ({big}) => (
  <Svg>
    <rect width={1920} height={1080} fill="#BFE3F5" />
    <circle cx={1500} cy={180} r={80} fill="#FFE08A" />
    <ellipse cx={700} cy={760} rx={900} ry={160} fill="#79B35C" />
    <rect y={720} width={1920} height={360} fill="#8CC56B" />
    <rect x={1280} y={440} width={460} height={280} fill="#E7CFA0" stroke={D} strokeWidth={5} />
    <polygon points="1240,450 1510,300 1780,450" fill="#C0392B" stroke={D} strokeWidth={5} />
    <rect x={1470} y={560} width={80} height={160} fill="#6b4a2f" stroke={D} strokeWidth={4} />
    {Array.from({length: 14}).map((_, i) => <rect key={i} x={20 + i * 140} y={790} width={14} height={80} fill="#B58B5A" stroke={D} strokeWidth={3} />)}
    <rect y={810} width={1920} height={12} fill="#B58B5A" stroke={D} strokeWidth={3} />
    <Cow x={420} y={900} s={0.9} />
    <Hen x={1100} y={1000} />
    <Hen x={1250} y={1030} />
    {big && (
      <>
        <rect x={60} y={420} width={420} height={300} fill="#E7CFA0" stroke={D} strokeWidth={5} />
        <polygon points="20,430 270,290 520,430" fill="#C0392B" stroke={D} strokeWidth={5} />
        <Cow x={1500} y={960} s={0.8} />
        <Cow x={800} y={1010} s={0.7} />
        <Cow x={1750} y={1020} s={0.6} />
        <Hen x={320} y={1030} />
        <Hen x={1650} y={860} />
        <Hen x={620} y={870} />
      </>
    )}
  </Svg>
);

export const Bus: React.FC<{x: number}> = ({x}) => (
  <svg width={1} height={1} style={{position: 'absolute', left: x, top: 0, overflow: 'visible'}}>
    <rect x={-270} y={700} width={540} height={210} rx={34} fill="#E6492D" stroke={D} strokeWidth={5} />
    <rect x={-270} y={810} width={540} height={26} fill="#FFC107" />
    {[-210, -110, -10, 90, 190].map((wx) => <rect key={wx} x={wx} y={730} width={70} height={60} rx={8} fill="#BFE3F5" stroke={D} strokeWidth={4} />)}
    <circle cx={-150} cy={915} r={52} fill="#333" stroke={D} strokeWidth={5} />
    <circle cx={150} cy={915} r={52} fill="#333" stroke={D} strokeWidth={5} />
    <circle cx={-150} cy={915} r={20} fill="#bbb" />
    <circle cx={150} cy={915} r={20} fill="#bbb" />
  </svg>
);
