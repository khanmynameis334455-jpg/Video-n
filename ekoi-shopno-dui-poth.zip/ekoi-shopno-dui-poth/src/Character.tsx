import React from 'react';
import {useG} from './Scene';

const D = '#222222';
export type Expr = 'happy' | 'sad' | 'surprised' | 'angry' | 'worry' | 'cry' | 'laugh';
export type Pose = 'idle' | 'wave' | 'head' | 'phone' | 'hug' | 'low';
export type Look = {
  skin: string; hair: string; hairStyle: 'short' | 'curly' | 'none'; top: string;
  topType: 'shirt' | 'panjabi' | 'saree'; bottom: string; bottomType: 'pants' | 'lungi' | 'saree'; shoe: string;
  bag?: boolean; gamchha?: boolean; beard?: boolean; cap?: boolean; tired?: boolean; bindi?: boolean; pallu?: boolean; stick?: boolean;
};

export const LOOKS: Record<string, Look> = {
  kabirKid: {skin: '#E0A370', hair: '#222', hairStyle: 'short', top: '#A9CDEF', topType: 'shirt', bottom: '#1F2A5A', bottomType: 'pants', shoe: '#6b5a45', bag: true},
  rafiqKid: {skin: '#E8B07E', hair: '#1b1b1b', hairStyle: 'curly', top: '#8DB4E2', topType: 'shirt', bottom: '#34507A', bottomType: 'pants', shoe: '#5a4636'},
  kabirAdult: {skin: '#D9965F', hair: '#222', hairStyle: 'short', top: '#B8A27A', topType: 'shirt', bottom: '#4F8FB5', bottomType: 'lungi', shoe: '#6b5a45', gamchha: true},
  rafiqAdult: {skin: '#E2A36F', hair: '#1b1b1b', hairStyle: 'curly', top: '#7A8AA3', topType: 'shirt', bottom: '#2E3F5C', bottomType: 'pants', shoe: '#444', tired: true},
  rafiqEid: {skin: '#E2A36F', hair: '#1b1b1b', hairStyle: 'curly', top: '#F6EFD9', topType: 'panjabi', bottom: '#E8E0C8', bottomType: 'pants', shoe: '#6b4a2f'},
  ma: {skin: '#D5955F', hair: '#222', hairStyle: 'none', top: '#D32F3F', topType: 'saree', bottom: '#D32F3F', bottomType: 'saree', shoe: '#222', bindi: true, pallu: true},
  elder1: {skin: '#C98E5D', hair: '#eee', hairStyle: 'short', top: '#F4F1E8', topType: 'shirt', bottom: '#4C97C9', bottomType: 'lungi', shoe: '#222', beard: true, stick: true},
  elder2: {skin: '#C98E5D', hair: '#eee', hairStyle: 'none', top: '#C9B8E8', topType: 'shirt', bottom: '#5AA0D0', bottomType: 'lungi', shoe: '#222', beard: true, cap: true},
  elder3: {skin: '#C98E5D', hair: '#eee', hairStyle: 'short', top: '#EFE3C6', topType: 'shirt', bottom: '#6E9FB8', bottomType: 'lungi', shoe: '#222', beard: true},
};

const Cap: React.FC<{x1: number; y1: number; x2: number; y2: number; w: number; c: string}> = ({x1, y1, x2, y2, w, c}) => (
  <g strokeLinecap="round">
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={D} strokeWidth={w + 6} />
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={c} strokeWidth={w} />
  </g>
);

const POSES: Record<Pose, [number, number]> = {
  idle: [6, -6], wave: [6, -150], head: [6, -168], phone: [6, -165], hug: [125, -125], low: [14, -14],
};

export const Character: React.FC<{
  x: number; y: number; S?: number; flip?: boolean; look: Look; expr?: Expr; pose?: Pose;
  talking?: boolean; tremble?: boolean; opacity?: number;
}> = ({x, y, S = 1.9, flip = false, look, expr = 'happy', pose = 'idle', talking = false, tremble = false, opacity = 1}) => {
  const g = useG();
  const bob = Math.sin(g / 16) * 4;
  const jx = tremble ? Math.sin(g * 2.3) * 3 : 0;
  const blink = g % 96 < 4;
  const [la, ra0] = POSES[pose];
  const ra = pose === 'wave' ? ra0 + Math.sin(g / 4) * 14 : ra0;
  const m = talking ? [0, 1, 2, 1, 0, 2, 1][Math.floor(g / 3) % 7] : 0;
  const eyeRy = expr === 'surprised' ? 16 : blink ? 1.5 : 13;
  const browY = expr === 'surprised' ? -8 : 0;
  const bl = expr === 'sad' || expr === 'cry' || expr === 'worry' ? -18 : expr === 'angry' ? 20 : 0;

  const arm = (sx: number, a: number, phone: boolean) => (
    <g transform={`translate(${sx},-190) rotate(${a})`}>
      <Cap x1={0} y1={0} x2={0} y2={78} w={22} c={look.skin} />
      <Cap x1={0} y1={0} x2={0} y2={38} w={24} c={look.top} />
      <circle cx={0} cy={86} r={13} fill={look.skin} stroke={D} strokeWidth={3} />
      {phone && <rect x={-9} y={62} width={18} height={34} rx={4} fill="#333" stroke={D} strokeWidth={2.5} />}
    </g>
  );

  const baseMouth = () => {
    if (expr === 'laugh') return <path d="M-20,-234 Q0,-196 20,-234Z" fill="#7a2e2e" stroke={D} strokeWidth={3} />;
    if (expr === 'surprised') return <ellipse cx={0} cy={-224} rx={9} ry={12} fill="#7a2e2e" stroke={D} strokeWidth={3} />;
    if (expr === 'sad' || expr === 'cry') return <path d="M-14,-220 Q0,-236 14,-220" fill="none" stroke={D} strokeWidth={4} strokeLinecap="round" />;
    if (expr === 'angry') return <path d="M-13,-222 Q0,-230 13,-222" fill="none" stroke={D} strokeWidth={4} strokeLinecap="round" />;
    if (expr === 'worry') return <path d="M-14,-226 Q-7,-232 0,-226 T14,-226" fill="none" stroke={D} strokeWidth={4} strokeLinecap="round" />;
    return <path d="M-17,-230 Q0,-210 17,-230" fill="none" stroke={D} strokeWidth={4} strokeLinecap="round" />;
  };

  return (
    <svg width={1} height={1} style={{position: 'absolute', left: x, top: y, overflow: 'visible', opacity}}>
      <g transform={`translate(${jx},0) scale(${flip ? -S : S},${S}) translate(0,${bob})`}>
        {/* ব্যাগ */}
        {look.bag && <rect x={-62} y={-200} width={34} height={96} rx={12} fill="#3D7A6B" stroke={D} strokeWidth={3} />}
        {/* নিচের অংশ */}
        {look.bottomType === 'pants' && (
          <>
            <Cap x1={-17} y1={-110} x2={-17} y2={-14} w={28} c={look.bottom} />
            <Cap x1={17} y1={-110} x2={17} y2={-14} w={28} c={look.bottom} />
            <ellipse cx={-19} cy={-6} rx={26} ry={11} fill={look.shoe} stroke={D} strokeWidth={3} />
            <ellipse cx={19} cy={-6} rx={26} ry={11} fill={look.shoe} stroke={D} strokeWidth={3} />
          </>
        )}
        {look.bottomType === 'lungi' && (
          <>
            <ellipse cx={-19} cy={-6} rx={22} ry={10} fill={look.skin} stroke={D} strokeWidth={3} />
            <ellipse cx={19} cy={-6} rx={22} ry={10} fill={look.skin} stroke={D} strokeWidth={3} />
            <polygon points="-50,-115 50,-115 58,-14 -58,-14" fill={look.bottom} stroke={D} strokeWidth={3} />
            {[-30, -10, 10, 30].map((lx) => <line key={lx} x1={lx} y1={-112} x2={lx * 1.15} y2={-17} stroke="#fff" strokeWidth={3} opacity={0.45} />)}
            <line x1={-54} y1={-60} x2={54} y2={-60} stroke="#fff" strokeWidth={3} opacity={0.45} />
          </>
        )}
        {look.bottomType === 'saree' && (
          <>
            <ellipse cx={-19} cy={-6} rx={22} ry={9} fill={look.skin} stroke={D} strokeWidth={3} />
            <ellipse cx={19} cy={-6} rx={22} ry={9} fill={look.skin} stroke={D} strokeWidth={3} />
            <polygon points="-52,-120 52,-120 66,-14 -66,-14" fill={look.bottom} stroke={D} strokeWidth={3} />
            <polygon points="-52,-120 -20,-120 20,-14 -20,-14" fill="#F2D9B0" opacity={0.8} />
          </>
        )}
        {/* শরীর */}
        {look.topType === 'panjabi' ? (
          <>
            <rect x={-46} y={-205} width={92} height={140} rx={26} fill={look.top} stroke={D} strokeWidth={3} />
            <line x1={0} y1={-205} x2={0} y2={-150} stroke={D} strokeWidth={3} />
          </>
        ) : (
          <rect x={-46} y={-205} width={92} height={look.topType === 'saree' ? 108 : 108} rx={28} fill={look.top} stroke={D} strokeWidth={3} />
        )}
        {look.topType === 'saree' && <polygon points="-46,-190 -10,-205 46,-120 46,-100 -10,-110" fill="#F2D9B0" opacity={0.75} />}
        {look.gamchha && <line x1={-38} y1={-195} x2={22} y2={-130} stroke="#D9534F" strokeWidth={14} strokeLinecap="round" />}
        {look.bag && <line x1={-30} y1={-204} x2={30} y2={-118} stroke="#2d5a4f" strokeWidth={8} />}
        {/* হাত */}
        {arm(-48, la, false)}
        {arm(48, ra, pose === 'phone')}
        {look.stick && <rect x={-86} y={-90} width={9} height={90} rx={4} fill="#C9A15B" stroke={D} strokeWidth={2.5} />}
        {/* মাথা */}
        {look.pallu && <path d="M-60,-250 Q-62,-322 0,-326 Q62,-322 60,-250 Q60,-198 42,-186 L-42,-186 Q-60,-198 -60,-250Z" fill="#D32F3F" stroke={D} strokeWidth={3} />}
        <circle cx={-50} cy={-250} r={11} fill={look.skin} stroke={D} strokeWidth={3} />
        <circle cx={50} cy={-250} r={11} fill={look.skin} stroke={D} strokeWidth={3} />
        <ellipse cx={0} cy={-250} rx={50} ry={54} fill={look.skin} stroke={D} strokeWidth={3} />
        {look.hairStyle === 'short' && <path d="M-51,-258 Q-54,-312 0,-314 Q54,-312 51,-258 Q30,-286 0,-282 Q-30,-286 -51,-258Z" fill={look.hair} stroke={D} strokeWidth={3} />}
        {look.hairStyle === 'curly' && (
          <g fill={look.hair} stroke={D} strokeWidth={3}>
            {[[-40, -292, 22], [-14, -306, 25], [16, -306, 25], [40, -292, 22], [-52, -270, 16], [52, -270, 16]].map(([cx, cy, r], i) => <circle key={i} cx={cx} cy={cy} r={r} />)}
          </g>
        )}
        {look.pallu && <path d="M-54,-262 Q-50,-312 0,-314 Q50,-312 54,-262 Q30,-290 0,-286 Q-30,-290 -54,-262Z" fill="#D32F3F" stroke={D} strokeWidth={3} />}
        {look.cap && <path d="M-48,-290 Q0,-340 48,-290 L48,-280 Q0,-296 -48,-280Z" fill="#fff" stroke={D} strokeWidth={3} />}
        {look.beard && <path d="M-46,-240 Q-42,-186 0,-182 Q42,-186 46,-240 Q22,-214 0,-216 Q-22,-214 -46,-240Z" fill="#f2f2f2" stroke={D} strokeWidth={3} />}
        {look.bindi && <circle cx={0} cy={-285} r={5} fill="#D32F3F" />}
        {look.tired && <><ellipse cx={-20} cy={-238} rx={13} ry={4} fill="#000" opacity={0.22} /><ellipse cx={20} cy={-238} rx={13} ry={4} fill="#000" opacity={0.22} /></>}
        {/* চোখ ও ভ্রু */}
        {[-20, 20].map((ex) => (
          <g key={ex}>
            <ellipse cx={ex} cy={-255} rx={11} ry={eyeRy} fill="#fff" stroke={D} strokeWidth={2.5} />
            {eyeRy > 5 && <circle cx={ex} cy={-254} r={5.5} fill={D} />}
          </g>
        ))}
        <line x1={-33} y1={-278 + browY} x2={-9} y2={-278 + browY} stroke={D} strokeWidth={5} strokeLinecap="round" transform={`rotate(${bl},-21,${-278 + browY})`} />
        <line x1={9} y1={-278 + browY} x2={33} y2={-278 + browY} stroke={D} strokeWidth={5} strokeLinecap="round" transform={`rotate(${-bl},21,${-278 + browY})`} />
        {/* মুখ */}
        {m === 0 && baseMouth()}
        {m === 1 && <ellipse cx={0} cy={-226} rx={9} ry={5} fill="#7a2e2e" stroke={D} strokeWidth={3} />}
        {m === 2 && <ellipse cx={0} cy={-224} rx={12} ry={11} fill="#7a2e2e" stroke={D} strokeWidth={3} />}
        {/* কান্না */}
        {expr === 'cry' && [-20, 20].map((ex, i) => {
          const t = (g * 3 + i * 20) % 50;
          return <circle key={ex} cx={ex} cy={-244 + t} r={5} fill="#5BB5F0" opacity={1 - t / 55} />;
        })}
      </g>
    </svg>
  );
};
