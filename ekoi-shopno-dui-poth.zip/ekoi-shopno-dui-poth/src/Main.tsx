import React from 'react';
import {AbsoluteFill, Audio, staticFile} from 'remotion';
import {fontFamily} from './font';
import {AllScenes} from './Scenes';
import {CalloutLayer, CaptionLayer} from './ui';

export const Main: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000', fontFamily}}>
    <Audio src={staticFile('voice.mp3')} />
    <AllScenes />
    <CalloutLayer />
    <CaptionLayer />
  </AbsoluteFill>
);
