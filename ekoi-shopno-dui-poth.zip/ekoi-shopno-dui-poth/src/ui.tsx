import React from 'react';
import {interpolate, spring, useCurrentFrame} from 'remotion';
import {useG} from './Scene';
import {CALLOUTS, CAPTIONS, FPS, sf} from './data';

type Timed = {at: number; until?: number};

export const Pop: React.FC<Timed & {emoji: string; x: number; y: number; size?: number; pulse?: boolean}> = ({emoji, x, y, size = 130, at, until, pulse}) => {
  const g = useG();
  const f = g - sf(at);
  if (f < 0 || (until !== undefined && g > sf(until))) return null;
  const k = spring({frame: f, fps: FPS, config: {damping: 9, stiffness: 140}});
  const sc = k * (pulse ? 1 + 0.08 * Math.sin(g / 5) : 1);
  return (
    <div style={{position: 'absolute', left: x, top: y + Math.sin(g / 12) * 10, transform: `translate(-50%,-50%) scale(${sc})`, fontSize: size, lineHeight: 1}}>{emoji}</div>
  );
};

export const Stamp: React.FC<Timed & {text: string; x: number; y: number; color?: string; size?: number; rot?: number}> = ({text, x, y, at, until, color = '#E53935', size = 110, rot = -4}) => {
  const g = useG();
  const f = g - sf(at);
  if (f < 0 || (until !== undefined && g > sf(until))) return null;
  const k = spring({frame: f, fps: FPS, config: {damping: 11, stiffness: 150}});
  const sc = interpolate(k, [0, 1], [2.4, 1]);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${sc})`, opacity: Math.min(1, f / 4), background: color, color: '#fff', border: '7px solid #222', borderRadius: 28, padding: '10px 44px', fontSize: size, fontWeight: 700, whiteSpace: 'nowrap', boxShadow: '8px 10px 0 rgba(0,0,0,.28)'}}>{text}</div>
  );
};

export const Pill: React.FC<Timed & {text: string; x: number; y: number; color?: string}> = ({text, x, y, at, until, color = '#FF9800'}) => {
  const g = useG();
  const f = g - sf(at);
  if (f < 0 || (until !== undefined && g > sf(until))) return null;
  const k = spring({frame: f, fps: FPS, config: {damping: 12}});
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${k})`, background: color, color: '#fff', border: '5px solid #222', borderRadius: 60, padding: '4px 36px', fontSize: 54, fontWeight: 700}}>{text}</div>
  );
};

export const Clock: React.FC<Timed & {x: number; y: number; size?: number; h0: number; h1: number}> = ({x, y, size = 300, at, until = at + 3, h0, h1}) => {
  const g = useG();
  if (g < sf(at) || g > sf(until)) return null;
  const p = interpolate(g, [sf(at), sf(until)], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const hour = ((h0 + (h1 - h0) * p) % 12) * 30;
  return (
    <svg width={size} height={size} viewBox="-100 -100 200 200" style={{position: 'absolute', left: x - size / 2, top: y - size / 2}}>
      <circle r={92} fill="#fff" stroke="#222" strokeWidth={7} />
      {Array.from({length: 12}).map((_, i) => <line key={i} x1={0} y1={-76} x2={0} y2={-84} stroke="#222" strokeWidth={4} transform={`rotate(${i * 30})`} />)}
      <line x1={0} y1={0} x2={0} y2={-48} stroke="#222" strokeWidth={9} strokeLinecap="round" transform={`rotate(${hour})`} />
      <line x1={0} y1={0} x2={0} y2={-70} stroke="#E53935" strokeWidth={5} strokeLinecap="round" transform={`rotate(${(g * 14) % 360})`} />
      <circle r={7} fill="#222" />
    </svg>
  );
};

export const CalloutLayer: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <>
      {CALLOUTS.map((c, i) => {
        const st = sf(c.a);
        if (f < st || f >= sf(c.b)) return null;
        const k = spring({frame: f - st, fps: FPS, config: {damping: 12, stiffness: 160}});
        const bx = Math.min(Math.max(c.x, c.w / 2 + 50), 1920 - c.w / 2 - 50);
        const tail = c.x - bx;
        return (
          <div key={i} style={{position: 'absolute', left: bx - c.w / 2, width: c.w, bottom: 1080 - (c.y - 38), transform: `scale(${k})`, transformOrigin: `${c.w / 2 + tail}px 100%`}}>
            <div style={{background: '#fff', border: '5px solid #222', borderRadius: 36, padding: '22px 34px', fontSize: 50, fontWeight: 700, color: '#222', textAlign: 'center', lineHeight: 1.35}}>{c.text}</div>
            <svg width={60} height={44} style={{position: 'absolute', left: c.w / 2 + tail - 30, bottom: -38}}>
              <polygon points="4,0 56,0 30,40" fill="#fff" />
              <polyline points="4,0 30,40 56,0" fill="none" stroke="#222" strokeWidth={5} strokeLinejoin="round" />
            </svg>
          </div>
        );
      })}
    </>
  );
};

export const CaptionLayer: React.FC = () => {
  const f = useCurrentFrame();
  if (CALLOUTS.some((c) => f >= sf(c.a) && f < sf(c.b))) return null;
  const cap = CAPTIONS.find((c) => f >= sf(c.a) && f < sf(c.b));
  if (!cap) return null;
  const l = f - sf(cap.a);
  const op = interpolate(l, [0, 8], [0, 1], {extrapolateRight: 'clamp'});
  const ty = interpolate(l, [0, 8], [30, 0], {extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 64, display: 'flex', justifyContent: 'center', opacity: op, transform: `translateY(${ty}px)`}}>
      <div style={{background: 'rgba(0,0,0,.55)', borderRadius: 50, padding: '10px 48px', fontSize: 66, fontWeight: 500, color: '#fff', whiteSpace: 'nowrap'}}>
        {cap.t.split('**').map((p, i) => (i % 2 ? <span key={i} style={{color: '#FFD54A', fontWeight: 700}}>{p}</span> : <span key={i}>{p}</span>))}
      </div>
    </div>
  );
};
